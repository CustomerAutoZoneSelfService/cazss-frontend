import{t as f,a as p}from"./BJAgsyaf.js";import"./CthYVxUA.js";import{t as g}from"./CAwsTucs.js";import{r as c}from"./w0IhE7qB.js";import{a as b,b as u}from"./BFfgUR7g.js";import{s as x}from"./CkcUZKPO.js";import{b as h}from"./Uli_MdUt.js";import{p as t}from"./B3kKM_fB.js";var _=f("<textarea></textarea>");function T(r,e){let o=t(e,"text",12,""),l=t(e,"placeholder",8,""),s=t(e,"disabled",8,!1),m=t(e,"useMonospace",8,!1),i=t(e,"transparentBackground",8,!1),n=t(e,"margin",8,!1),d=t(e,"marginSize",8,"1rem");var a=_();c(a),g(()=>{x(a,1,`h-50 w-full resize-none rounded-2xl p-5 shadow-md shadow-gray-300
	  ${m()?"font-mono":""}
	  ${i()?"bg-transparent":"bg-gray-light"}
	`),b(a,n()?`margin: ${d()};`:""),a.disabled=s(),u(a,"placeholder",l())}),h(a,o),p(r,a)}export{T};
