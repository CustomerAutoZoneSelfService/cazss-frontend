import{o as s,w as l}from"./CAwsTucs.js";function u(n,t,r,a,o){var i;s&&l();var e=(i=t.$$slots)==null?void 0:i[r],f=!1;e===!0&&(e=t.children,f=!0),e===void 0||e(n,f?()=>a:a)}export{u as s};
