import{ad as a}from"./CAwsTucs.js";a();
