import"../chunks/BJAgsyaf.js";import"../chunks/CthYVxUA.js";import{I as m}from"../chunks/B_PE8qm3.js";function t(o){m(o,{name:"Home",color:"#FF00FF"})}export{t as component};
