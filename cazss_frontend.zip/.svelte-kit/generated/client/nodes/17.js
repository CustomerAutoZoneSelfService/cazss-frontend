import * as universal from "../../../../src/routes/history/details/[range]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/history/details/[range]/+page.svelte";