export { matchers } from './matchers.js';

export const nodes = [
	() => import('./nodes/0'),
	() => import('./nodes/1'),
	() => import('./nodes/2'),
	() => import('./nodes/3'),
	() => import('./nodes/4'),
	() => import('./nodes/5'),
	() => import('./nodes/6'),
	() => import('./nodes/7'),
	() => import('./nodes/8'),
	() => import('./nodes/9'),
	() => import('./nodes/10'),
	() => import('./nodes/11'),
	() => import('./nodes/12'),
	() => import('./nodes/13'),
	() => import('./nodes/14'),
	() => import('./nodes/15'),
	() => import('./nodes/16'),
	() => import('./nodes/17'),
	() => import('./nodes/18'),
	() => import('./nodes/19')
];

export const server_loads = [0];

export const dictionary = {
		"/": [2],
		"/create": [3],
		"/demo/button": [4],
		"/demo/heading": [5],
		"/demo/input-table": [7],
		"/demo/input": [6],
		"/demo/list": [8],
		"/demo/select": [9],
		"/demo/text-area": [11],
		"/demo/text": [10],
		"/demo/username-button": [12],
		"/edit/[id]": [13],
		"/endpoint/[id]": [14],
		"/history": [15],
		"/history/admin": [16],
		"/history/details/[range]": [17],
		"/history/user": [18],
		"/invokeEndpoint": [19]
	};

export const hooks = {
	handleError: (({ error }) => { console.error(error) }),
	
	reroute: (() => {}),
	transport: {}
};

export const decoders = Object.fromEntries(Object.entries(hooks.transport).map(([k, v]) => [k, v.decode]));

export const hash = false;

export const decode = (type, value) => decoders[type](value);

export { default as root } from '../root.js';