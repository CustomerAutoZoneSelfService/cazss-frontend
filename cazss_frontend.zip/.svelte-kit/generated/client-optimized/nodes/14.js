import * as universal from "../../../../src/routes/endpoint/[id]/+page.ts";
export { universal };
export { default as component } from "../../../../src/routes/endpoint/[id]/+page.svelte";