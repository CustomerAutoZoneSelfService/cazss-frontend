import "clsx";
import { n as attr_style, q as attr_class, t as stringify } from "../../chunks/index.js";
import { I as Icon_1 } from "../../chunks/Icon.js";
function AppContainer($$payload, $$props) {
  let { children } = $$props;
  $$payload.out += `<div class="flex h-screen w-screen overflow-hidden">`;
  children($$payload);
  $$payload.out += `<!----></div>`;
}
function Sidebar($$payload) {
  $$payload.out += `<div class="fixed top-4 z-50 transition-all duration-300"${attr_style(`left: ${stringify("13.5rem")}`)}><button aria-label="Expandir o colapsar menú">`;
  Icon_1($$payload, { name: "PanelRight", size: 24, color: "black" });
  $$payload.out += `<!----></button></div> <div class="flex h-full flex-row justify-between"><div${attr_class(`sidebar h-100% flex min-h-screen flex-col justify-between ${stringify("expanded")}`, "svelte-ov5sic")}><nav class="mt-12 flex flex-col gap-2 px-2"><a href="/"><div${attr_class(`nav-item flex cursor-pointer items-center space-x-3 rounded-lg p-3 ${stringify("")}`, "svelte-ov5sic")}>`;
  Icon_1($$payload, { name: "Home", size: 24, color: "white" });
  $$payload.out += `<!----> `;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="text-white">Home</span>`;
  }
  $$payload.out += `<!--]--></div></a> <a href="/history"><div${attr_class(`nav-item flex cursor-pointer items-center space-x-3 rounded-lg p-3 ${stringify("")}`, "svelte-ov5sic")}>`;
  Icon_1($$payload, { name: "Clock", size: 24, color: "white" });
  $$payload.out += `<!----> `;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="text-white">History</span>`;
  }
  $$payload.out += `<!--]--></div></a> <a href="/create"><div${attr_class(`nav-item flex cursor-pointer items-center space-x-3 rounded-lg p-3 ${stringify("")}`, "svelte-ov5sic")}>`;
  Icon_1($$payload, { name: "Plus", size: 24, color: "white" });
  $$payload.out += `<!----> `;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="text-white">Create</span>`;
  }
  $$payload.out += `<!--]--></div></a></nav> <div class="flex items-center p-4 text-white"><div class="flex h-8 w-8 items-center justify-center rounded-full bg-white/20">`;
  Icon_1($$payload, { name: "User", size: 24, color: "white" });
  $$payload.out += `<!----></div> `;
  {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="ml-3">Username</span>`;
  }
  $$payload.out += `<!--]--></div></div></div>`;
}
function _layout($$payload, $$props) {
  let { children } = $$props;
  AppContainer($$payload, {
    children: ($$payload2) => {
      Sidebar($$payload2);
      $$payload2.out += `<!----> <div class="grow overflow-y-auto p-8">`;
      children($$payload2);
      $$payload2.out += `<!----></div>`;
    }
  });
}
export {
  _layout as default
};
