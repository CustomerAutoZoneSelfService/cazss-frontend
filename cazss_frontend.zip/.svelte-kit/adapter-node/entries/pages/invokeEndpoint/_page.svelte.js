import { z as ensure_array_like, v as escape_html } from "../../../chunks/index.js";
import { B as Button } from "../../../chunks/Button.js";
import { H as HeadingFormat } from "../../../chunks/HeadingFormat.js";
import { I as Input } from "../../../chunks/Input.js";
import { T as TextArea } from "../../../chunks/TextArea.js";
import { T as TextFormat } from "../../../chunks/TextFormat.js";
function _page($$payload) {
  const sections = [
    {
      id: 1,
      title: "Body variables",
      label: "SKU",
      tooltip: "(?)"
    },
    {
      id: 2,
      title: "Params / Headers",
      label: "ClientId"
    }
  ];
  const each_array = ensure_array_like(sections);
  $$payload.out += `<main class="mx-auto flex w-full flex-col items-start gap-10 p-10">`;
  HeadingFormat($$payload, {
    variant: "primary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->Get PnA by <span class="font-light text-yellow-500">sku</span>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    size: "body",
    children: ($$payload2) => {
      $$payload2.out += `<!---->Get price and availability based on SKU.`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> <!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let section = each_array[$$index];
    $$payload.out += `<div class="flex w-full flex-col gap-4">`;
    HeadingFormat($$payload, {
      as: "h3",
      children: ($$payload2) => {
        $$payload2.out += `<!---->${escape_html(section.title)}`;
      },
      $$slots: { default: true }
    });
    $$payload.out += `<!----> <div class="flex-cols flex items-center gap-4">`;
    TextFormat($$payload, {
      size: "body",
      children: ($$payload2) => {
        $$payload2.out += `<!---->${escape_html(section.label)} `;
        if (section.tooltip) {
          $$payload2.out += "<!--[-->";
          $$payload2.out += `<span class="cursor-pointer text-red-500">${escape_html(section.tooltip)}</span>`;
        } else {
          $$payload2.out += "<!--[!-->";
        }
        $$payload2.out += `<!--]-->`;
      },
      $$slots: { default: true }
    });
    $$payload.out += `<!----> <div class="h-auto w-[301px]">`;
    Input($$payload, { text: "", boxSize: "sm" });
    $$payload.out += `<!----></div></div></div>`;
  }
  $$payload.out += `<!--]--> <span class="flex min-w-lg items-center justify-center gap-4">`;
  Button($$payload, {
    variant: "primary",
    type: "submit",
    size: "lg",
    className: "w-[300px] h-14 shadow-md",
    children: ($$payload2) => {
      $$payload2.out += `<!---->Send`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></span> `;
  HeadingFormat($$payload, {
    as: "h3",
    children: ($$payload2) => {
      $$payload2.out += `<!---->Raw Response (200 OK)`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> <div class="w-3xl">`;
  TextArea($$payload, { disabled: false });
  $$payload.out += `<!----></div></main>`;
}
export {
  _page as default
};
