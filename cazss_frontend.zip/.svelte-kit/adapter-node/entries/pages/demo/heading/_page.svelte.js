import "clsx";
import { H as HeadingFormat } from "../../../../chunks/HeadingFormat.js";
function _page($$payload) {
  $$payload.out += `<main class="mx-auto my-8 max-w-2/3 space-y-4"><h1 class="text-3xl font-bold">Heading format component</h1> <div><h2 class="text-2xl">As</h2> `;
  HeadingFormat($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->Default (h1) as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    as: "h1",
    children: ($$payload2) => {
      $$payload2.out += `<!---->h1 as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    as: "h2",
    children: ($$payload2) => {
      $$payload2.out += `<!---->h2 as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    as: "h3",
    children: ($$payload2) => {
      $$payload2.out += `<!---->h3 as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    as: "h4",
    children: ($$payload2) => {
      $$payload2.out += `<!---->h4 as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    as: "h5",
    children: ($$payload2) => {
      $$payload2.out += `<!---->h5 as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    as: "h6",
    children: ($$payload2) => {
      $$payload2.out += `<!---->h6 as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">Variant</h2> `;
  HeadingFormat($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->Default (primary)`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    variant: "primary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->primary variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    variant: "secondary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->secondary variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  HeadingFormat($$payload, {
    variant: "muted",
    children: ($$payload2) => {
      $$payload2.out += `<!---->muted variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">Disabled</h2> `;
  HeadingFormat($$payload, {
    disabled: true,
    children: ($$payload2) => {
      $$payload2.out += `<!---->Disabled`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div></main>`;
}
export {
  _page as default
};
