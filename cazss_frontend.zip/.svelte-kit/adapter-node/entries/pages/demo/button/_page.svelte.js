import "clsx";
import { B as Button } from "../../../../chunks/Button.js";
function _page($$payload) {
  $$payload.out += `<main class="mx-auto my-8 max-w-2/3 space-y-4"><h1 class="text-3xl font-bold">Button component</h1> <div><h2 class="text-2xl">Variant</h2> `;
  Button($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->Default (primary) variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    variant: "primary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->primary variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    variant: "secondary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->secondary variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    variant: "text",
    children: ($$payload2) => {
      $$payload2.out += `<!---->text variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">Size</h2> `;
  Button($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->Default (md) size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    size: "sm",
    children: ($$payload2) => {
      $$payload2.out += `<!---->sm size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    size: "md",
    children: ($$payload2) => {
      $$payload2.out += `<!---->md size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    size: "lg",
    children: ($$payload2) => {
      $$payload2.out += `<!---->lg size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">Disabled</h2> `;
  Button($$payload, {
    disabled: true,
    children: ($$payload2) => {
      $$payload2.out += `<!---->disabled`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <form action="" method="POST"><h2 class="text-2xl">Type</h2> <input class="mb-2 block border-1 border-black p-2" value="Hello, World!"> `;
  Button($$payload, {
    children: ($$payload2) => {
      $$payload2.out += `<!---->default (button) type`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    type: "button",
    children: ($$payload2) => {
      $$payload2.out += `<!---->button type`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    type: "submit",
    children: ($$payload2) => {
      $$payload2.out += `<!---->submit type`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  Button($$payload, {
    type: "reset",
    children: ($$payload2) => {
      $$payload2.out += `<!---->reset type`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></form></main>`;
}
export {
  _page as default
};
