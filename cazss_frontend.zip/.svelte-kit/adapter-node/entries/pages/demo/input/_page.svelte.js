import { A as copy_payload, B as assign_payload, v as escape_html } from "../../../../chunks/index.js";
import { I as Input } from "../../../../chunks/Input.js";
function _page($$payload) {
  let isInputDisabled = false;
  let endpointTitleText = "", urlText = "", skuText = "";
  function printText() {
    console.log(endpointTitleText + " " + urlText + " " + skuText);
  }
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="ml-10 w-5xl">`;
    Input($$payload2, {
      name: "SomeName",
      placeholder: "Type here...",
      boxSize: "sm",
      handleInput: printText,
      get text() {
        return endpointTitleText;
      },
      set text($$value) {
        endpointTitleText = $$value;
        $$settled = false;
      }
    });
    $$payload2.out += `<!----> <br> `;
    Input($$payload2, {
      placeholder: "Or here...",
      boxSize: "md",
      handleChange: printText,
      get text() {
        return urlText;
      },
      set text($$value) {
        urlText = $$value;
        $$settled = false;
      }
    });
    $$payload2.out += `<!----> <br> `;
    Input($$payload2, {
      placeholder: "Can't type here, though...",
      boxSize: "full",
      isDisabled: isInputDisabled,
      get text() {
        return skuText;
      },
      set text($$value) {
        skuText = $$value;
        $$settled = false;
      }
    });
    $$payload2.out += `<!----></div> <br> <button>The following text is being accessed from the parent: ${escape_html(endpointTitleText)}, ${escape_html(urlText)}, ${escape_html(skuText)}</button> <button>Click me to enable/disable the third input</button>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
}
export {
  _page as default
};
