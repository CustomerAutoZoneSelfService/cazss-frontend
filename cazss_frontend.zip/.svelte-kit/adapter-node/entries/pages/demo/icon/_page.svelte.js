import "clsx";
import { I as Icon_1 } from "../../../../chunks/Icon.js";
function _page($$payload) {
  Icon_1($$payload, { name: "Home", color: "#FF00FF" });
}
export {
  _page as default
};
