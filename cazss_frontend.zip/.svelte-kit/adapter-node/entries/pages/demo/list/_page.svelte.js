import "clsx";
import { L as List } from "../../../../chunks/List.js";
function _page($$payload) {
  $$payload.out += `<main class="mx-auto my-8 max-w-2/3 space-y-4"><h1 class="text-3xl font-bold">List component</h1> <div><h2 class="text-2xl">Direction</h2> <h3 class="text-xl">vertical (default) direction</h3> `;
  List($$payload, {
    direction: "vertical",
    children: ($$payload2) => {
      $$payload2.out += `<li>First</li> <li>Second</li> <li>Third</li>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> <h3 class="text-xl">horizontal direction</h3> `;
  List($$payload, {
    direction: "horizontal",
    children: ($$payload2) => {
      $$payload2.out += `<li>First</li> <li>Second</li> <li>Third</li>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">Type</h2> <h3 class="text-xl">ul (default) type</h3> `;
  List($$payload, {
    type: "ul",
    children: ($$payload2) => {
      $$payload2.out += `<li>First</li> <li>Second</li> <li>Third</li>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> <h3 class="text-xl">ol type</h3> `;
  List($$payload, {
    type: "ol",
    children: ($$payload2) => {
      $$payload2.out += `<li>First</li> <li>Second</li> <li>Third</li>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">List</h2> <h3 class="text-xl">true (default) list</h3> `;
  List($$payload, {
    list: true,
    children: ($$payload2) => {
      $$payload2.out += `<li>First</li> <li>Second</li> <li>Third</li>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> <h3 class="text-xl">false list</h3> `;
  List($$payload, {
    list: false,
    children: ($$payload2) => {
      $$payload2.out += `<li>First</li> <li>Second</li> <li>Third</li>`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div></main>`;
}
export {
  _page as default
};
