import { A as copy_payload, B as assign_payload } from "../../../../chunks/index.js";
import { T as TextArea } from "../../../../chunks/TextArea.js";
function _page($$payload) {
  let text;
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    TextArea($$payload2, {
      placeholder: "Some text...",
      useMonospace: true,
      transparentBackground: true,
      get text() {
        return text;
      },
      set text($$value) {
        text = $$value;
        $$settled = false;
      }
    });
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
}
export {
  _page as default
};
