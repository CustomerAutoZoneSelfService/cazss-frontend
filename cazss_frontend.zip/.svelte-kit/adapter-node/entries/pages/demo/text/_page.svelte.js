import "clsx";
import { T as TextFormat } from "../../../../chunks/TextFormat.js";
function _page($$payload) {
  $$payload.out += `<main class="mx-auto my-8 max-w-2/3 space-y-4"><h1 class="text-3xl font-bold">Text format component</h1> <div><h2 class="text-2xl">as</h2> `;
  TextFormat($$payload, {
    as: "p",
    children: ($$payload2) => {
      $$payload2.out += `<!---->p (default) as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    as: "span",
    children: ($$payload2) => {
      $$payload2.out += `<!---->span as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    as: "div",
    children: ($$payload2) => {
      $$payload2.out += `<!---->div as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    as: "label",
    children: ($$payload2) => {
      $$payload2.out += `<!---->label as`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">variant</h2> `;
  TextFormat($$payload, {
    variant: "primary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->primary (default) variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    variant: "secondary",
    children: ($$payload2) => {
      $$payload2.out += `<!---->secondary variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    variant: "muted",
    children: ($$payload2) => {
      $$payload2.out += `<!---->muted variant`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">size</h2> `;
  TextFormat($$payload, {
    size: "subtitle",
    children: ($$payload2) => {
      $$payload2.out += `<!---->subtitle size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    size: "body",
    children: ($$payload2) => {
      $$payload2.out += `<!---->body (default) size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    size: "caption",
    children: ($$payload2) => {
      $$payload2.out += `<!---->caption size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----> `;
  TextFormat($$payload, {
    size: "label",
    children: ($$payload2) => {
      $$payload2.out += `<!---->label size`;
    },
    $$slots: { default: true }
  });
  $$payload.out += `<!----></div></main>`;
}
export {
  _page as default
};
