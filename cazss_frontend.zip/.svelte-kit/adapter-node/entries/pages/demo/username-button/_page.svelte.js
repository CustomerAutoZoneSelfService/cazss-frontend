import "clsx";
import { v as escape_html } from "../../../../chunks/index.js";
import { I as Icon_1 } from "../../../../chunks/Icon.js";
function AccountDropdownMenu($$payload, $$props) {
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--> `;
  {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]-->`;
}
function UsernameButton($$payload, $$props) {
  let username = "John Doe";
  let { isSidebarCollapsed = false } = $$props;
  function getUserData() {
    username = "SomeUsername";
  }
  getUserData();
  $$payload.out += `<div class="account-menu-wrapper relative mb-1"><button id="username-button" class="bg-accent-red hover:bg-accent-red-dark flex h-full w-full rounded-lg p-3 duration-300 hover:cursor-pointer hover:transition">`;
  Icon_1($$payload, { name: "User", color: "white" });
  $$payload.out += `<!----> `;
  if (!isSidebarCollapsed) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<span class="mt-1 ml-3 text-white">${escape_html(username)}</span>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--></button> `;
  AccountDropdownMenu($$payload);
  $$payload.out += `<!----></div>`;
}
function _page($$payload) {
  let isSidebarCollapsed = false;
  $$payload.out += `<div class="absolute bottom-5">`;
  UsernameButton($$payload, { isSidebarCollapsed });
  $$payload.out += `<!----></div>`;
}
export {
  _page as default
};
