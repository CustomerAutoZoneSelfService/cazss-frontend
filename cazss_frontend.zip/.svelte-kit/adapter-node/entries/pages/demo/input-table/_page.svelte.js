import "clsx";
import { m as pop, p as push } from "../../../../chunks/index.js";
import { V as VariableType, I as InputTable } from "../../../../chunks/RequestVariable.js";
function _page($$payload, $$props) {
  push();
  let endpointId = 0;
  let responseId = 0;
  let variableType = VariableType.header;
  let ExampleVariables = [
    {
      requestVariableId: 0,
      endpointId,
      type: variableType,
      key: "invoiceId",
      defaultValue: "7248374827",
      customizable: false,
      description: "lorem"
    }
  ];
  let ExampleResponses = [
    {
      responsePatternId: 0,
      responseId: 0,
      parentId: null,
      pattern: "",
      name: "response1",
      description: "lorem",
      isLeaf: false
    }
  ];
  let HeadersPrompt = {
    endpointId,
    variableType,
    requestVariables: ExampleVariables
  };
  let ResponsesPrompt = {
    responseId,
    responsePatterns: ExampleResponses
  };
  InputTable($$payload, { prompt: HeadersPrompt });
  $$payload.out += `<!----> `;
  InputTable($$payload, { prompt: ResponsesPrompt });
  $$payload.out += `<!----> <button>Send</button>`;
  pop();
}
export {
  _page as default
};
