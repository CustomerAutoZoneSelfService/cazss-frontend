import "clsx";
import { S as Select } from "../../../../chunks/Select.js";
function _page($$payload) {
  const options = [
    { value: "1", label: "First" },
    { value: "2", label: "Second" },
    { value: "3", label: "Third" }
  ];
  $$payload.out += `<main class="mx-auto my-8 max-w-2/3 space-y-4"><h1 class="text-3xl font-bold">Select component</h1> <div><h2 class="text-2xl">options</h2> `;
  Select($$payload, { options });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">selected</h2> `;
  Select($$payload, { options, selected: "2" });
  $$payload.out += `<!----></div> <div><h2 class="text-2xl">disabled</h2> `;
  Select($$payload, { options, disabled: true });
  $$payload.out += `<!----></div></main>`;
}
export {
  _page as default
};
