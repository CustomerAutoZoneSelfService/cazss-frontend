import { w as fallback, x as attr, y as bind_props, A as copy_payload, B as assign_payload, m as pop, p as push } from "../../../chunks/index.js";
import { H as HeadingFormat } from "../../../chunks/HeadingFormat.js";
import { T as TextArea } from "../../../chunks/TextArea.js";
import { V as VariableType, I as InputTable } from "../../../chunks/RequestVariable.js";
import { B as Button } from "../../../chunks/Button.js";
import { S as Select } from "../../../chunks/Select.js";
import { I as Input } from "../../../chunks/Input.js";
import { T as TextFormat } from "../../../chunks/TextFormat.js";
import { g as goto } from "../../../chunks/client.js";
function CheckBox($$payload, $$props) {
  let checked = fallback($$props["checked"], false);
  $$payload.out += `<input type="checkbox" class="size-5"${attr("checked", checked, true)}>`;
  bind_props($$props, { checked });
}
function _page($$payload, $$props) {
  push();
  const methodNames = ["GET", "POST", "PUT", "DELETE"];
  const methods = methodNames.map((method) => ({ value: method, label: method }));
  let authNames = ["BEARER_TOKEN_1", "BEARER_TOKEN_2"];
  let authStrategies = authNames.map((authStrategy) => ({ value: authStrategy, label: authStrategy }));
  let categoryNames = ["INVOICE", "CACHE"];
  let categories = categoryNames.map((category) => ({ value: category, label: category }));
  let statusCodeNames = ["200", "201"];
  let statusCodes = statusCodeNames.map((statusCode) => ({ value: statusCode, label: statusCode }));
  let step = 1;
  let endpointId = 0;
  let responseId = 0;
  let template = "";
  let responseDescription = "";
  let endpoint = {
    title: "",
    description: "",
    method: "GET",
    url: "",
    authenticationStrategy: "",
    category: "",
    enabled: true
  };
  let headersPrompt = { endpointId, variableType: VariableType.header };
  let inlineParamPrompt = {
    endpointId,
    variableType: VariableType.inlline_param
  };
  let queryStringPrompt = {
    endpointId,
    variableType: VariableType.query_string
  };
  let bodyVariablesPrompt = { endpointId, variableType: VariableType.body };
  let responsesPrompt = { responseId };
  function goToNextPage() {
    step++;
  }
  function goToPreviousPage() {
    step--;
  }
  function registerEndpoint() {
    goto();
  }
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    $$payload2.out += `<div class="align-items justify-center">`;
    if (step === 1) {
      $$payload2.out += "<!--[-->";
      $$payload2.out += `<main class="flex-1 bg-white p-8"><div class="mb-6 flex items-center justify-between"><div><h1 class="text-2xl font-bold">New Endpoint</h1> `;
      TextFormat($$payload2, {
        as: "p",
        variant: "primary",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Create a New Endpoint`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----></div> <div class="flex items-center"></div></div> <form class="space-y-6"><div class="flex items-center space-x-4">`;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Title:`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Input($$payload2, {
        boxSize: "md",
        get text() {
          return endpoint.title;
        },
        set text($$value) {
          endpoint.title = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----> `;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Enabled:`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      CheckBox($$payload2, {
        get checked() {
          return endpoint.enabled;
        },
        set checked($$value) {
          endpoint.enabled = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div> <div>`;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Description:`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      TextArea($$payload2, {
        get text() {
          return endpoint.description;
        },
        set text($$value) {
          endpoint.description = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div> <div class="flex items-center space-x-8"><div class="flex items-center space-x-2">`;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Method:`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Select($$payload2, {
        options: methods,
        get selected() {
          return endpoint.method;
        },
        set selected($$value) {
          endpoint.method = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div> <div class="flex flex-1 items-center space-x-2">`;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->URL`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Input($$payload2, {
        boxSize: "full",
        get text() {
          return endpoint.url;
        },
        set text($$value) {
          endpoint.url = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div></div> <div class="flex items-center space-x-8"><div class="flex flex-1 items-center space-x-2">`;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Authentication Strategy:`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Select($$payload2, {
        options: authStrategies,
        get selected() {
          return endpoint.authenticationStrategy;
        },
        set selected($$value) {
          endpoint.authenticationStrategy = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div> <div class="flex flex-1 items-center space-x-2">`;
      TextFormat($$payload2, {
        as: "label",
        variant: "primary",
        size: "subtitle",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Category:`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Select($$payload2, {
        options: categories,
        get selected() {
          return endpoint.category;
        },
        set selected($$value) {
          endpoint.category = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div></div></form></main>`;
    } else {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> `;
    if (step === 2) {
      $$payload2.out += "<!--[-->";
      $$payload2.out += `<div class="flex flex-col"><div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Headers`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      InputTable($$payload2, { prompt: headersPrompt });
      $$payload2.out += `<!----></div> <div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->In Line Params`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      InputTable($$payload2, { prompt: inlineParamPrompt });
      $$payload2.out += `<!----></div> <div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Query String`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      InputTable($$payload2, { prompt: queryStringPrompt });
      $$payload2.out += `<!----></div> <div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Body Template`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      TextArea($$payload2, {
        get text() {
          return template;
        },
        set text($$value) {
          template = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div> <div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Body Variables`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      InputTable($$payload2, { prompt: bodyVariablesPrompt });
      $$payload2.out += `<!----></div></div>`;
    } else {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> `;
    if (step === 3) {
      $$payload2.out += "<!--[-->";
      $$payload2.out += `<div><div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Status Code`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      Select($$payload2, { options: statusCodes });
      $$payload2.out += `<!----></div> <div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Response Description`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      TextArea($$payload2, {
        get text() {
          return responseDescription;
        },
        set text($$value) {
          responseDescription = $$value;
          $$settled = false;
        }
      });
      $$payload2.out += `<!----></div> <div class="py-2">`;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Response Patterns`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      InputTable($$payload2, { prompt: responsesPrompt });
      $$payload2.out += `<!----></div></div>`;
    } else {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> <div class="flex justify-end gap-x-20 py-8">`;
    if (step > 1) {
      $$payload2.out += "<!--[-->";
      Button($$payload2, {
        type: "button",
        size: "md",
        variant: "secondary",
        onClick: goToPreviousPage,
        children: ($$payload3) => {
          $$payload3.out += `<!---->BACK`;
        },
        $$slots: { default: true }
      });
    } else {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--> `;
    if (step < 3) {
      $$payload2.out += "<!--[-->";
      Button($$payload2, {
        type: "button",
        size: "md",
        variant: "primary",
        onClick: goToNextPage,
        children: ($$payload3) => {
          $$payload3.out += `<!---->NEXT`;
        },
        $$slots: { default: true }
      });
    } else {
      $$payload2.out += "<!--[!-->";
      Button($$payload2, {
        type: "button",
        size: "md",
        variant: "primary",
        onClick: registerEndpoint,
        children: ($$payload3) => {
          $$payload3.out += `<!---->REGISTER`;
        },
        $$slots: { default: true }
      });
    }
    $$payload2.out += `<!--]--></div></div>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  bind_props($$props, { registerEndpoint });
  pop();
}
export {
  _page as default
};
