import { w as fallback, J as slot, v as escape_html, y as bind_props, A as copy_payload, B as assign_payload, m as pop, p as push, z as ensure_array_like } from "../../../../chunks/index.js";
import { B as Button } from "../../../../chunks/Button.js";
import { H as HeadingFormat } from "../../../../chunks/HeadingFormat.js";
import { T as TextArea } from "../../../../chunks/TextArea.js";
import { T as TextFormat } from "../../../../chunks/TextFormat.js";
import { I as Input } from "../../../../chunks/Input.js";
import { L as List } from "../../../../chunks/List.js";
function Tooltip($$payload, $$props) {
  let value = fallback($$props["value"], "");
  $$payload.out += `<span class="group relative cursor-pointer"><!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!----> <span class="absolute top-full left-1/2 z-10 mt-2 w-max -translate-x-1/2 rounded bg-black px-2 py-1 text-xs whitespace-nowrap text-white opacity-0 transition-opacity group-hover:opacity-100">${escape_html(value)}</span></span>`;
  bind_props($$props, { value });
}
const BASE_URL = "http://localhost:8080";
class ApiWrapper {
  constructor(baseUrl = BASE_URL, headers = {}) {
    this.baseUrl = baseUrl;
    this.headers = headers;
  }
  // Primitives
  async request(path, options = {}) {
    const url = this.baseUrl + path;
    const response = await fetch(url, {
      ...options,
      headers: {
        ...this.headers,
        ...options.headers
      }
    });
    if (!response.ok)
      throw new Error(
        `[API Wrapper] The request to ${url} (${options.method}) failed. Status: ${response.status} ${response.statusText}, body: ${await response.text()}`
      );
    else return await response.json();
  }
  get(path) {
    return this.request(path, { method: "GET" });
  }
  post(path, body) {
    return this.request(path, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });
  }
  // Endpoints
  getAllServices() {
    return this.get("/services/getAllServices");
  }
  getServiceById(id) {
    return this.get(`/services/getServiceById/${id}`);
  }
  executeService(id, body) {
    return this.post(`/services/executeService/${id}`, body);
  }
}
function _page($$payload, $$props) {
  push();
  const api = new ApiWrapper();
  let { data } = $$props;
  console.log("accesed to endpoint page");
  let endpoint = {
    id: data.id,
    name: "",
    description: "",
    active: false,
    method: "GET",
    url: "",
    responses: [],
    filters: [],
    variables: [],
    requestBody: ""
  };
  let headers = endpoint.variables.filter((variable) => variable.type === "HEADER");
  let body = endpoint.variables.filter((variable) => variable.type === "BODY");
  let inline_params = endpoint.variables.filter((variable) => variable.type === "INLINE_PARAM");
  let query_strings = endpoint.variables.filter((variable) => variable.type === "QUERY_STRING");
  let variableTypes = [headers, body, inline_params, query_strings];
  let variableTypeHeadingMap = /* @__PURE__ */ new Map();
  variableTypeHeadingMap.set("HEADER", "Headers");
  variableTypeHeadingMap.set("BODY", "Body Variables");
  variableTypeHeadingMap.set("INLINE_PARAM", "Inline Parameters");
  variableTypeHeadingMap.set("QUERY_STRING", "Query Strings");
  let requestService = {
    id: data.id,
    headers: [],
    body: [],
    inline: [],
    queryString: []
  };
  let ExecutionResponse = {
    status: { code: 0, description: "" },
    response: []
  };
  const initializeRequestService = (variables) => {
    const newHeaders = [];
    const newBody = [];
    const newInline = [];
    const newQueryString = [];
    variables.forEach((variable) => {
      const kv = {
        key: variable.keyName,
        value: variable.defaultValue ?? ""
      };
      switch (variable.type) {
        case "HEADER":
          newHeaders.push(kv);
          break;
        case "BODY":
          newBody.push(kv);
          break;
        case "INLINE_PARAM":
          newInline.push(kv);
          break;
        case "QUERY_STRING":
          newQueryString.push(kv);
          break;
      }
    });
    requestService.headers = newHeaders;
    requestService.body = newBody;
    requestService.inline = newInline;
    requestService.queryString = newQueryString;
  };
  const findRequestKeyValue = (type, keyName) => {
    let targetArray;
    switch (type) {
      case "HEADER":
        targetArray = requestService.headers;
        break;
      case "BODY":
        targetArray = requestService.body;
        break;
      case "INLINE_PARAM":
        targetArray = requestService.inline;
        break;
      case "QUERY_STRING":
        targetArray = requestService.queryString;
        break;
    }
    return targetArray?.find((kv) => kv.key === keyName);
  };
  const fetchEndpoint = async (id) => {
    try {
      endpoint = await api.getServiceById(id);
      initializeRequestService(endpoint.variables);
    } catch (error) {
      console.log(error);
    }
  };
  const executeEndpoint = async () => {
    try {
      ExecutionResponse = await api.executeService(data.id, requestService);
    } catch (error) {
      console.log(error);
    }
  };
  const handleSend = async () => {
    try {
      await executeEndpoint();
      console.log("Sending endpoint");
      console.log(requestService);
    } catch (error) {
      if (error) {
        console.log(`There was an error with the request for the endpoint: ${data.id}`);
      }
    }
  };
  fetchEndpoint(data.id);
  let $$settled = true;
  let $$inner_payload;
  function $$render_inner($$payload2) {
    const each_array = ensure_array_like(variableTypes);
    $$payload2.out += `<main class="space-y-10 p-10"><div class="flex flex-col gap-6">`;
    HeadingFormat($$payload2, {
      children: ($$payload3) => {
        $$payload3.out += `<!---->${escape_html(endpoint.name)}`;
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!----> `;
    TextFormat($$payload2, {
      size: "body",
      variant: "primary",
      children: ($$payload3) => {
        $$payload3.out += `<!---->${escape_html(endpoint.description)}`;
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!----></div> <div class="flex flex-col gap-4"><!--[-->`;
    for (let index = 0, $$length = each_array.length; index < $$length; index++) {
      let variables = each_array[index];
      if (variables.length > 0) {
        $$payload2.out += "<!--[-->";
        const each_array_1 = ensure_array_like(variables);
        $$payload2.out += `<div class="flex flex-col gap-4">`;
        HeadingFormat($$payload2, {
          as: "h4",
          children: ($$payload3) => {
            $$payload3.out += `<!---->${escape_html(variableTypeHeadingMap.get(variables[0].type))}`;
          },
          $$slots: { default: true }
        });
        $$payload2.out += `<!----> <div class="flex flex-col"><!--[-->`;
        for (let $$index = 0, $$length2 = each_array_1.length; $$index < $$length2; $$index++) {
          let variable = each_array_1[$$index];
          const requestValue = findRequestKeyValue(variable.type, variable.keyName);
          $$payload2.out += `<div class="flex items-center gap-4"><div class="flex flex-row gap-2">`;
          TextFormat($$payload2, {
            as: "label",
            size: "body",
            className: "whitespace-nowrap",
            children: ($$payload3) => {
              $$payload3.out += `<!---->${escape_html(variable.keyName)}`;
            },
            $$slots: { default: true }
          });
          $$payload2.out += `<!----> `;
          if (variable.description) {
            $$payload2.out += "<!--[-->";
            Tooltip($$payload2, {
              value: variable.description,
              children: ($$payload3) => {
                $$payload3.out += `<span class="cursor-pointer text-red-500">(?)</span>`;
              },
              $$slots: { default: true }
            });
          } else {
            $$payload2.out += "<!--[!-->";
          }
          $$payload2.out += `<!--]--></div> <div>`;
          if (!variable.customizable) {
            $$payload2.out += "<!--[-->";
            Input($$payload2, {
              boxSize: "full",
              disabled: true,
              get text() {
                return variable.defaultValue;
              },
              set text($$value) {
                variable.defaultValue = $$value;
                $$settled = false;
              }
            });
          } else if (requestValue) {
            $$payload2.out += "<!--[1-->";
            Input($$payload2, {
              boxSize: "full",
              disabled: !variable.customizable,
              get text() {
                return requestValue.value;
              },
              set text($$value) {
                requestValue.value = $$value;
                $$settled = false;
              }
            });
          } else {
            $$payload2.out += "<!--[!-->";
          }
          $$payload2.out += `<!--]--></div></div>`;
        }
        $$payload2.out += `<!--]--></div></div>`;
      } else {
        $$payload2.out += "<!--[!-->";
      }
      $$payload2.out += `<!--]-->`;
    }
    $$payload2.out += `<!--]--></div> `;
    Button($$payload2, {
      variant: "primary",
      type: "submit",
      size: "lg",
      onClick: handleSend,
      children: ($$payload3) => {
        $$payload3.out += `<!---->Send`;
      },
      $$slots: { default: true }
    });
    $$payload2.out += `<!----> <div class="space-y-4">`;
    if (ExecutionResponse.status.code) {
      $$payload2.out += "<!--[-->";
      HeadingFormat($$payload2, {
        as: "h3",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Response `;
          Tooltip($$payload3, {
            value: ExecutionResponse.status.description,
            children: ($$payload4) => {
              $$payload4.out += `<!---->(Status code: ${escape_html(ExecutionResponse.status.code)})`;
            },
            $$slots: { default: true }
          });
          $$payload3.out += `<!---->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      List($$payload2, {
        type: "ul",
        children: ($$payload3) => {
          const each_array_2 = ensure_array_like(Object.entries(ExecutionResponse.response));
          $$payload3.out += `<!--[-->`;
          for (let index = 0, $$length = each_array_2.length; index < $$length; index++) {
            let [key, value] = each_array_2[index];
            $$payload3.out += `<li><b>${escape_html(key)}:</b> ${escape_html(value.join(", "))}</li>`;
          }
          $$payload3.out += `<!--]-->`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      HeadingFormat($$payload2, {
        as: "h4",
        children: ($$payload3) => {
          $$payload3.out += `<!---->Raw body`;
        },
        $$slots: { default: true }
      });
      $$payload2.out += `<!----> `;
      TextArea($$payload2, {
        disabled: true,
        text: ExecutionResponse.response ? JSON.stringify(ExecutionResponse.response) : ""
      });
      $$payload2.out += `<!---->`;
    } else {
      $$payload2.out += "<!--[!-->";
    }
    $$payload2.out += `<!--]--></div></main>`;
  }
  do {
    $$settled = true;
    $$inner_payload = copy_payload($$payload);
    $$render_inner($$inner_payload);
  } while (!$$settled);
  assign_payload($$payload, $$inner_payload);
  pop();
}
export {
  _page as default
};
