import { w as fallback, x as attr, v as escape_html, y as bind_props, t as stringify, m as pop, p as push, z as ensure_array_like } from "../../chunks/index.js";
function EndpointCard($$payload, $$props) {
  let id = $$props["id"];
  let title = $$props["title"];
  let description = $$props["description"];
  let starred = fallback($$props["starred"], false);
  $$payload.out += `<div class="group bg-gray-light hover:bg-accent-red relative rounded-3xl shadow-lg"><a${attr("href", `/endpoint/${stringify(id)}`)}><div class="h-full w-full rounded-3xl p-6"><div class="text-near-black text-2xl font-bold group-hover:text-white" style="display: -webkit-box; -webkit-line-clamp: 2; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;">${escape_html(title)}</div> <p class="text-near-black mt-2 text-base group-hover:text-white" style="display: -webkit-box; -webkit-line-clamp: 3; -webkit-box-orient: vertical; overflow: hidden; text-overflow: ellipsis;">${escape_html(description)}</p></div></a> <button class="text-near-black hover:bg-accent-red-dark absolute right-5 bottom-5 flex h-7 w-7 items-center justify-center rounded-full group-hover:text-white">${escape_html(starred ? "★" : "☆")}</button></div>`;
  bind_props($$props, { id, title, description, starred });
}
function SearchBar($$payload, $$props) {
  push();
  let searchQuery = "";
  $$payload.out += `<div class="relative flex h-15 w-full overflow-hidden rounded-full border border-gray-300 bg-white shadow-md"><input type="text" placeholder="Search..." class="flex-1 px-4 py-2 text-gray-800 focus:outline-none"${attr("value", searchQuery)}></div>`;
  pop();
}
function _page($$payload, $$props) {
  push();
  let endpoints = [];
  let filteredEndpoints = [];
  $$payload.out += `<div class="flex h-full flex-col items-center gap-5"><div class="mt-10 mb-5 w-6/10">`;
  SearchBar($$payload, {
    allData: endpoints.map((e) => e.name)
  });
  $$payload.out += `<!----></div> <div class="flex w-full flex-col justify-center"><h1 class="py-5 text-lg font-bold text-gray-500">Endpoints</h1> <main class="grid grid-cols-4 gap-12">`;
  if (filteredEndpoints.length === 0) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<p class="col-span-4 text-gray-500">No endpoints found</p>`;
  } else {
    $$payload.out += "<!--[!-->";
    const each_array = ensure_array_like(filteredEndpoints);
    $$payload.out += `<!--[-->`;
    for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
      let endpoint = each_array[$$index];
      EndpointCard($$payload, {
        id: endpoint.endpointId,
        title: endpoint.name,
        description: endpoint.description
      });
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]--></main></div></div>`;
  pop();
}
export {
  _page as default
};
