import * as server from '../entries/pages/_layout.server.ts.js';

export const index = 0;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_layout.svelte.js')).default;
export { server };
export const server_id = "src/routes/+layout.server.ts";
export const imports = ["_app/immutable/nodes/0.CAJltQAW.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/w0IhE7qB.js","_app/immutable/chunks/mGcug4E0.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/BFfgUR7g.js","_app/immutable/chunks/B_PE8qm3.js","_app/immutable/chunks/B3kKM_fB.js","_app/immutable/chunks/CMFJS5-7.js","_app/immutable/chunks/Dfn3cyoV.js","_app/immutable/chunks/DVSPkZoX.js","_app/immutable/chunks/BxHfPZnh.js"];
export const stylesheets = ["_app/immutable/assets/0.Qz8Bntgo.css"];
export const fonts = [];
