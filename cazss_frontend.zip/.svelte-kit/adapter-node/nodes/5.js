

export const index = 5;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/demo/heading/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/5.-jnszrZz.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/C451jprT.js","_app/immutable/chunks/w0IhE7qB.js","_app/immutable/chunks/CMFJS5-7.js","_app/immutable/chunks/DVSPkZoX.js","_app/immutable/chunks/BFfgUR7g.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/BxHfPZnh.js","_app/immutable/chunks/B3kKM_fB.js"];
export const stylesheets = [];
export const fonts = [];
