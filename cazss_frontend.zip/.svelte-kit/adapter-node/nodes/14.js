import * as universal from '../entries/pages/endpoint/_id_/_page.ts.js';

export const index = 14;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/endpoint/_id_/_page.svelte.js')).default;
export { universal };
export const universal_id = "src/routes/endpoint/[id]/+page.ts";
export const imports = ["_app/immutable/nodes/14.DsmSo_2G.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/Cz6O6ZrF.js","_app/immutable/chunks/w0IhE7qB.js","_app/immutable/chunks/mGcug4E0.js","_app/immutable/chunks/Dfn3cyoV.js","_app/immutable/chunks/Wuo_dGK-.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/CMFJS5-7.js","_app/immutable/chunks/BFfgUR7g.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/BxHfPZnh.js","_app/immutable/chunks/B3kKM_fB.js","_app/immutable/chunks/C451jprT.js","_app/immutable/chunks/DVSPkZoX.js","_app/immutable/chunks/CX2AdlmD.js","_app/immutable/chunks/Uli_MdUt.js","_app/immutable/chunks/BGdoFiXi.js","_app/immutable/chunks/Do3juAKm.js","_app/immutable/chunks/ClaXxdYS.js"];
export const stylesheets = ["_app/immutable/assets/Button.DP6Pbvzf.css"];
export const fonts = [];
