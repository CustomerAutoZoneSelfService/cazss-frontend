

export const index = 2;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.Cq4y-HOr.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/mGcug4E0.js","_app/immutable/chunks/Dfn3cyoV.js","_app/immutable/chunks/BxHfPZnh.js","_app/immutable/chunks/FJl6_oa5.js","_app/immutable/chunks/Cz6O6ZrF.js","_app/immutable/chunks/w0IhE7qB.js","_app/immutable/chunks/BFfgUR7g.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/B3kKM_fB.js","_app/immutable/chunks/Uli_MdUt.js"];
export const stylesheets = [];
export const fonts = [];
