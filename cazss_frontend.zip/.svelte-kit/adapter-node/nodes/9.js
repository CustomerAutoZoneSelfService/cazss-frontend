

export const index = 9;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/demo/list/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/9.hR02VD_e.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/ClaXxdYS.js","_app/immutable/chunks/mGcug4E0.js","_app/immutable/chunks/CMFJS5-7.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/B3kKM_fB.js"];
export const stylesheets = [];
export const fonts = [];
