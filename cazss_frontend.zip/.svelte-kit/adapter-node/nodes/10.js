

export const index = 10;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/demo/select/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/10.C7r6zM84.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/wkdLRN1T.js","_app/immutable/chunks/Cz6O6ZrF.js","_app/immutable/chunks/w0IhE7qB.js","_app/immutable/chunks/Dfn3cyoV.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/B3kKM_fB.js"];
export const stylesheets = [];
export const fonts = [];
