

export const index = 12;
let component_cache;
export const component = async () => component_cache ??= (await import('../entries/pages/demo/text-area/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/12.erMyi51p.js","_app/immutable/chunks/BJAgsyaf.js","_app/immutable/chunks/CAwsTucs.js","_app/immutable/chunks/CthYVxUA.js","_app/immutable/chunks/CX2AdlmD.js","_app/immutable/chunks/w0IhE7qB.js","_app/immutable/chunks/BFfgUR7g.js","_app/immutable/chunks/CkcUZKPO.js","_app/immutable/chunks/Uli_MdUt.js","_app/immutable/chunks/B3kKM_fB.js"];
export const stylesheets = [];
export const fonts = [];
