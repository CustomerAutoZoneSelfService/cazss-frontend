import { w as fallback, q as attr_class, n as attr_style, x as attr, v as escape_html, y as bind_props } from "./index.js";
function TextArea($$payload, $$props) {
  let text = fallback($$props["text"], "");
  let placeholder = fallback($$props["placeholder"], "");
  let disabled = fallback($$props["disabled"], false);
  let useMonospace = fallback($$props["useMonospace"], false);
  let transparentBackground = fallback($$props["transparentBackground"], false);
  let margin = fallback($$props["margin"], false);
  let marginSize = fallback($$props["marginSize"], "1rem");
  $$payload.out += `<textarea${attr_class(`h-50 w-full resize-none rounded-2xl p-5 shadow-md shadow-gray-300
	  ${useMonospace ? "font-mono" : ""}
	  ${transparentBackground ? "bg-transparent" : "bg-gray-light"}
	`)}${attr_style(margin ? `margin: ${marginSize};` : "")}${attr("disabled", disabled, true)}${attr("placeholder", placeholder)}>`;
  const $$body = escape_html(text);
  if ($$body) {
    $$payload.out += `${$$body}`;
  }
  $$payload.out += `</textarea>`;
  bind_props($$props, {
    text,
    placeholder,
    disabled,
    useMonospace,
    transparentBackground,
    margin,
    marginSize
  });
}
export {
  TextArea as T
};
