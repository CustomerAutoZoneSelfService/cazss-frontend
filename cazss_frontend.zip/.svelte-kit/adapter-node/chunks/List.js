import { w as fallback, q as attr_class, J as slot, y as bind_props, t as stringify } from "./index.js";
function List($$payload, $$props) {
  let className = fallback($$props["className"], "");
  let direction = fallback($$props["direction"], "vertical");
  let type = fallback($$props["type"], "ul");
  let list = fallback($$props["list"], true);
  const baseStyles = direction === "horizontal" ? "flex gap-8 p-2" : "flex flex-col gap-2 p-2";
  if (type === "ul") {
    $$payload.out += "<!--[-->";
    $$payload.out += `<ul${attr_class(`${stringify(baseStyles)} ${stringify(list ? "list-disc" : "")} ${stringify(className)}`)}><!---->`;
    slot($$payload, $$props, "default", {});
    $$payload.out += `<!----></ul>`;
  } else {
    $$payload.out += "<!--[!-->";
    $$payload.out += `<ol${attr_class(`${stringify(baseStyles)} ${stringify(list ? "list-decimal" : "")} ${stringify(className)}`)}><!---->`;
    slot($$payload, $$props, "default", {});
    $$payload.out += `<!----></ol>`;
  }
  $$payload.out += `<!--]-->`;
  bind_props($$props, { className, direction, type, list });
}
export {
  List as L
};
