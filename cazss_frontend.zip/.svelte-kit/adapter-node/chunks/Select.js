import { w as fallback, z as ensure_array_like, q as attr_class, x as attr, v as escape_html, y as bind_props, t as stringify } from "./index.js";
function Select($$payload, $$props) {
  let options = fallback($$props["options"], () => [], true);
  let selected = fallback($$props["selected"], "");
  let disabled = fallback($$props["disabled"], false);
  const each_array = ensure_array_like(options);
  $$payload.out += `<div class="relative w-48"><select${attr_class(`bg-gray-light w-full appearance-none rounded-2xl px-4 py-1 pr-10 text-black shadow-xl ${stringify(disabled ? "cursor-not-allowed" : "")}`)}${attr("disabled", disabled, true)}><!--[-->`;
  for (let $$index = 0, $$length = each_array.length; $$index < $$length; $$index++) {
    let option = each_array[$$index];
    $$payload.out += `<option${attr("value", option.value)}>${escape_html(option.label)}</option>`;
  }
  $$payload.out += `<!--]--></select> <div class="pointer-events-none absolute inset-y-0 right-3 flex items-center"><div class="h-0 w-2 border-t-8 border-r-8 border-l-8 border-t-[#B7B5B5] border-r-transparent border-l-transparent"></div></div></div>`;
  bind_props($$props, { options, selected, disabled });
}
export {
  Select as S
};
