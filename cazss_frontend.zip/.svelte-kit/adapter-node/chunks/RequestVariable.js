import { z as ensure_array_like, v as escape_html, x as attr, y as bind_props, m as pop, p as push } from "./index.js";
import { I as Icon_1 } from "./Icon.js";
function InputTable($$payload, $$props) {
  push();
  let { prompt } = $$props;
  let variables = "endpointId" in prompt ? prompt.requestVariables ?? [] : prompt.responsePatterns ?? [];
  function getVariables() {
    if ("endpointId" in prompt) {
      return variables.filter((variable) => variable.key !== "");
    } else {
      return variables.filter((variable) => variable.name !== "");
    }
  }
  addNewRow();
  function addNewRow() {
    if ("endpointId" in prompt) {
      variables.push({
        requestVariableId: 0,
        endpointId: prompt.endpointId,
        type: prompt.variableType,
        key: "",
        defaultValue: "",
        customizable: false,
        description: ""
      });
    } else {
      variables.push({
        responsePatternId: 0,
        responseId: prompt.responseId,
        parentId: null,
        pattern: "",
        name: "",
        description: "",
        isLeaf: false
      });
    }
  }
  function generateTestId(rowIndex, columnIndex) {
    return `cell-row-${rowIndex}-col-${columnIndex}`;
  }
  const each_array = ensure_array_like(variables);
  $$payload.out += `<table data-testid="variable-table" class="table-auto border-collapse border border-gray-400"><thead><tr><th class="border border-gray-300">${escape_html("endpointId" in prompt ? "Key" : "Name")}</th>`;
  if (!("endpointId" in prompt)) {
    $$payload.out += "<!--[-->";
    $$payload.out += `<th class="border border-gray-300">Parent ID</th>`;
  } else {
    $$payload.out += "<!--[!-->";
  }
  $$payload.out += `<!--]--><th class="border border-gray-300">${escape_html("endpointId" in prompt ? "Value" : "Pattern")}</th><th class="border border-gray-300">${escape_html("endpointId" in prompt ? "Customizable" : "Is Leaf")}</th><th class="border border-gray-300">Description</th></tr></thead><tbody><!--[-->`;
  for (let index = 0, $$length = each_array.length; index < $$length; index++) {
    let variable = each_array[index];
    if ("key" in variable) {
      $$payload.out += "<!--[-->";
      $$payload.out += `<tr><th${attr("data-testid", generateTestId(index, 0))} class="border border-gray-300"><input${attr("value", variable.key)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 1))} class="border border-gray-300"><input${attr("value", variable.defaultValue)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 2))} class="border border-gray-300"><input type="checkbox"${attr("checked", variable.customizable, true)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 3))} class="group relative flex flex-row border border-gray-300 align-middle"><input${attr("value", variable.description)} class="p-1"> <div${attr("data-testid", "delete-row-" + index)} class="ml-2 hidden items-center justify-center group-hover:flex"><button>`;
      Icon_1($$payload, { name: "Trash2" });
      $$payload.out += `<!----></button></div></th></tr>`;
    } else {
      $$payload.out += "<!--[!-->";
      $$payload.out += `<tr><th${attr("data-testid", generateTestId(index, 0))} class="border border-gray-300"><input${attr("value", variable.name)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 1))} class="border border-gray-300"><input${attr("value", variable.parentId)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 2))} class="border border-gray-300"><input${attr("value", variable.pattern)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 3))} class="border border-gray-300"><input type="checkbox"${attr("checked", variable.isLeaf, true)} class="p-1"></th><th${attr("data-testid", generateTestId(index, 4))} class="group relative flex flex-row border border-gray-300 align-middle"><input${attr("value", variable.description)} class="p-1"> <div${attr("data-testid", "delete-row-" + index)} class="ml-2 hidden items-center justify-center group-hover:flex"><button>`;
      Icon_1($$payload, { name: "Trash2" });
      $$payload.out += `<!----></button></div></th></tr>`;
    }
    $$payload.out += `<!--]-->`;
  }
  $$payload.out += `<!--]--></tbody></table>`;
  bind_props($$props, { getVariables });
  pop();
}
var VariableType = /* @__PURE__ */ ((VariableType2) => {
  VariableType2[VariableType2["header"] = 0] = "header";
  VariableType2[VariableType2["query_string"] = 1] = "query_string";
  VariableType2[VariableType2["inlline_param"] = 2] = "inlline_param";
  VariableType2[VariableType2["body"] = 3] = "body";
  return VariableType2;
})(VariableType || {});
export {
  InputTable as I,
  VariableType as V
};
