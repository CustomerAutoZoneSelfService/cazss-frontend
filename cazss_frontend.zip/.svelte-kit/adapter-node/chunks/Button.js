import { D as sanitize_props, E as rest_props, w as fallback, F as spread_attributes, G as clsx, J as slot, y as bind_props, m as pop, p as push } from "./index.js";
function Button($$payload, $$props) {
  const $$sanitized_props = sanitize_props($$props);
  const $$restProps = rest_props($$sanitized_props, [
    "variant",
    "size",
    "disabled",
    "type",
    "onClick",
    "iconOnly"
  ]);
  push();
  let variant = fallback($$props["variant"], "primary");
  let size = fallback($$props["size"], "md");
  let disabled = fallback($$props["disabled"], false);
  let type = fallback($$props["type"], "button");
  let onClick = fallback($$props["onClick"], null);
  let iconOnly = fallback($$props["iconOnly"], false);
  function computeClasses() {
    let baseClasses = "inline-flex items-center justify-center font-bold rounded-md focus:outline-none transition-all duration-200 disabled:opacity-50 disabled:cursor-not-allowed";
    let variantClasses = "";
    switch (variant) {
      case "primary":
        variantClasses = `bg-accent-red text-white hover:bg-accent-red-dark
                                   hover:shadow-md`;
        break;
      case "secondary":
        variantClasses = "bg-gray-200 text-black hover:bg-gray-300 active:bg-gray-400";
        break;
      case "text":
        variantClasses = `text-accent-red bg-transparent hover:text-accent-red-dark
                                hover:underline`;
        break;
    }
    let sizeClasses = "";
    switch (size) {
      case "sm":
        sizeClasses = iconOnly ? "w-8 h-8" : "px-3 py-1 text-sm";
        break;
      case "md":
        sizeClasses = iconOnly ? "w-10 h-10" : "px-4 py-2 text-base";
        break;
      case "lg":
        sizeClasses = iconOnly ? "w-12 h-12" : "px-6 py-3 text-lg";
        break;
    }
    const iconOnlyClass = iconOnly ? "rounded-full" : "";
    return `${baseClasses} ${variantClasses} ${sizeClasses} ${iconOnlyClass}`;
  }
  $$payload.out += `<button${spread_attributes(
    {
      type,
      class: clsx(computeClasses()),
      disabled,
      ...$$restProps
    }
  )}><!---->`;
  slot($$payload, $$props, "default", {});
  $$payload.out += `<!----></button>`;
  bind_props($$props, {
    variant,
    size,
    disabled,
    type,
    onClick,
    iconOnly
  });
  pop();
}
export {
  Button as B
};
