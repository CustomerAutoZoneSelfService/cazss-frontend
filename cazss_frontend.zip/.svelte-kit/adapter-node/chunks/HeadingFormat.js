import { w as fallback, I as element, y as bind_props, m as pop, p as push, J as slot, q as attr_class, x as attr, G as clsx } from "./index.js";
function HeadingFormat($$payload, $$props) {
  push();
  let variantStyles, disabledStyles, sizeStyles, combinedClasses;
  let as = fallback($$props["as"], "h1");
  let variant = fallback($$props["variant"], "primary");
  let disabled = fallback($$props["disabled"], false);
  let onClick = fallback($$props["onClick"], null);
  let baseStyles = "transition-all duration-200";
  variantStyles = {
    primary: "text-black font-semibold",
    secondary: "text-primary font-semibold",
    muted: "text-gray-medium font-semibold"
  }[variant];
  disabledStyles = disabled ? "opacity-50 cursor-not-allowed pointer-events-none" : "hover:text-blue-500 active:text-blue-700 cursor-pointer";
  sizeStyles = {
    h1: "text-4xl",
    h2: "text-3xl",
    h3: "text-2xl",
    h4: "text-xl",
    h5: "text-lg",
    h6: "text-base"
  }[as];
  combinedClasses = `${baseStyles} ${variantStyles} ${disabledStyles} ${sizeStyles}`;
  element(
    $$payload,
    as,
    () => {
      $$payload.out += `${attr_class(clsx(combinedClasses))}${attr("role", onClick && !disabled ? "button" : void 0)}${attr("tabindex", onClick && !disabled ? 0 : void 0)}`;
    },
    () => {
      $$payload.out += `<!---->`;
      slot($$payload, $$props, "default", {});
      $$payload.out += `<!---->`;
    }
  );
  bind_props($$props, { as, variant, disabled, onClick });
  pop();
}
export {
  HeadingFormat as H
};
