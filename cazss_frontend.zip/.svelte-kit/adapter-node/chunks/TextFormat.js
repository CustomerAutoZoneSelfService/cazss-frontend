import { w as fallback, I as element, y as bind_props, m as pop, p as push, J as slot, q as attr_class, G as clsx } from "./index.js";
function TextFormat($$payload, $$props) {
  push();
  let variantStyles, sizeStyles, combinedClasses;
  let as = fallback($$props["as"], "p");
  let variant = fallback($$props["variant"], "primary");
  let size = fallback($$props["size"], "body");
  let className = fallback($$props["className"], "");
  let baseFont = "font-inter";
  variantStyles = {
    primary: "text-gray-900",
    secondary: "text-white",
    muted: "text-gray-400",
    none: ""
  }[variant];
  sizeStyles = {
    subtitle: "text-lg font-medium leading-normal",
    body: "text-base font-normal leading-relaxed",
    caption: "text-sm font-normal leading-normal",
    label: "text-sm font-medium leading-tight"
  }[size];
  combinedClasses = `${baseFont} ${variantStyles} ${sizeStyles} ${className}`.trim();
  element(
    $$payload,
    as,
    () => {
      $$payload.out += `${attr_class(clsx(combinedClasses))}`;
    },
    () => {
      $$payload.out += `<!---->`;
      slot($$payload, $$props, "default", {});
      $$payload.out += `<!---->`;
    }
  );
  bind_props($$props, { as, variant, size, className });
  pop();
}
export {
  TextFormat as T
};
