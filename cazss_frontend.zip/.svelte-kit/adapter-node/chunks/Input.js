import { w as fallback, q as attr_class, x as attr, y as bind_props, m as pop, p as push, t as stringify } from "./index.js";
const InputBoxSizeTranslations = {
  sm: "w-80",
  md: "w-lg",
  full: "w-full"
};
function Input($$payload, $$props) {
  push();
  let text = $$props["text"];
  let boxSize = $$props["boxSize"];
  let disabled = fallback($$props["disabled"], false);
  let textBoxSizeCSS = InputBoxSizeTranslations[boxSize];
  $$payload.out += `<input${attr_class(`${stringify(textBoxSizeCSS)} bg-gray-light my-3 h-10 rounded-2xl px-3 shadow-xl`)}${attr("value", text)}${attr("disabled", disabled, true)}>`;
  bind_props($$props, { text, boxSize, disabled });
  pop();
}
export {
  Input as I
};
